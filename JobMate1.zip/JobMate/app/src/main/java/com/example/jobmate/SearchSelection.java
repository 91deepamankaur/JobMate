package com.example.jobmate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class SearchSelection extends AppCompatActivity {
    private RadioGroup radioCateGroup;
    private RadioButton radioCateButton;
    private Button btnDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_selection);
        addListenerOnButton();
    }
    public void addListenerOnButton() {

        radioCateGroup = (RadioGroup) findViewById(R.id.radioCat);
        btnDisplay = (Button) findViewById(R.id.btnDisplay);

        btnDisplay.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                // get selected radio button from radioGroup
                int selectedId = radioCateGroup.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                radioCateButton = (RadioButton) findViewById(selectedId);

                Toast.makeText(SearchSelection.this,
                        radioCateButton.getText(), Toast.LENGTH_SHORT).show();

            }

        });

    }
}
