package com.example.jobmate;

public interface Constant {

    String WEB_SERVICE_HOST = "10.0.2.2";
    String WEB_SERVICE_PORT = "8080";
}
