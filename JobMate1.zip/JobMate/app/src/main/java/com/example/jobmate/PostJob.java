package com.example.jobmate;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PostJob extends AppCompatActivity {
    private static final String TAG = "PostJob";
    private TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private Button button;
    private Button button1;
    EditText emailET,companynameET, jobtypeET, descriptionET, salaryET, addressET ;
    String email,companyname, jobtype, description, salary, address;
    Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_job);
        emailET = findViewById(R.id.email);
        companynameET = findViewById(R.id.companyname);
        jobtypeET = findViewById(R.id.jobtype);
        descriptionET = findViewById(R.id.description);
        salaryET = findViewById(R.id.salary);
        addressET = findViewById(R.id.address);


    }

    public void add(View view) {
        email = emailET.getText().toString();
        companyname = companynameET.getText().toString();
        jobtype = jobtypeET.getText().toString();
        description = descriptionET.getText().toString();
        salary = salaryET.getText().toString();
        address = addressET.getText().toString();

        //validation start
        if (email.equalsIgnoreCase("")) {
            emailET.setError("Please enter password");
            emailET.requestFocus();
            return;
        }
        if (companyname.equalsIgnoreCase("")) {
            companynameET.setError("Please enter email");
            companynameET.requestFocus();
            return;
        }
        if (jobtype.equalsIgnoreCase("")) {
            jobtypeET.setError("Please enter first name");
            jobtypeET.requestFocus();
            return;
        }
        if (description.equalsIgnoreCase("")) {
            descriptionET.setError("Please enter last name");
            descriptionET.requestFocus();
            return;
        }
        if (salary.equalsIgnoreCase("")) {
            salaryET.setError("Please enter date of birth");
            salaryET.requestFocus();
            return;
        }
        if (address.equalsIgnoreCase("")) {
            addressET.setError("Please enter password");
            addressET.requestFocus();
            return;
        }


        //validation end

        new Job(PostJob.this, email,companyname,jobtype,description,salary,address).execute();
    }

    private class Job extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressBar;
        private String email;
        private String companyname;
        private String title;
        private String description;
        private String salary;
        private String address;


        public Job(Activity activity,String email,String companyname,
                        String jobtype, String description, String salary, String address){
            progressBar = new ProgressDialog(activity);
            this.email =email;
            this.companyname = companyname;
            this.title = jobtype;
            this.description = description;
            this.salary = salary;
            this.address = address;

        }

        protected void onPreExecute(){
            progressBar.setMessage("Loading...");
            progressBar.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            URL url = null;
            BufferedReader reader = null;
            StringBuilder stringBuilder = new StringBuilder();

            try {
                url = new URL("http://"+ Constant.WEB_SERVICE_HOST +":"+Constant.WEB_SERVICE_PORT+"/Web_Application/webresources/mobile/post&"+email+"&"+companyname+"&"+title+"&"+description+"&"+address+"&"+salary);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                // uncomment this if you want to write output to this url

                connection.setDoInput(true);
                connection.setInstanceFollowRedirects( false );

                // give it 15 seconds to respond
                connection.setReadTimeout(15*1000);
                connection.connect();
                // read the output from the server
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }

                System.out.println("url: "+stringBuilder.toString());
            }
            catch (Exception e) {
                e.printStackTrace();
                try {
                    throw e;
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            finally {
                if (reader != null) {
                    try{
                        reader.close();
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return stringBuilder.toString();
        }
        @Override

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            System.out.println(result);
            try {
                JSONObject loginResponse = new JSONObject(result);
                if(loginResponse.length()!=0 &&
                        loginResponse.get("status").toString().equalsIgnoreCase("OK") ) {


                    Intent intent = new Intent(PostJob.this, loginFinder.class);
                    startActivity(intent);
                    progressBar.dismiss();
                }
                else{
                    Toast toast = Toast.makeText(getApplicationContext(),"Something went wrong, please try again.",Toast.LENGTH_LONG);

                    progressBar.dismiss();
                    toast.show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}