/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;


import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import static javax.ws.rs.HttpMethod.POST;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;

/**
 * REST Web Service
 *
 * @author JASIL JOSE
 */
@Path("mobile")
public class Mobile {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of Mobile
     */
    public Mobile() {
    }

    /**
     * Retrieves representation of an instance of main.Mobile
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public String getXml() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of Mobile
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
    
    @GET
    @Path("login&{username}&{password}")
    @Produces("application/json")
    //@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String login(@PathParam("username") String username, @PathParam("password") String password) throws SQLException, JSONException{
        JSONObject user = new JSONObject();
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
        System.out.println("username: "+username+"  password: "+password);
            if(username!="" | password.trim()!=""){
            //username!=null | password!=null !username.equalsIgnoreCase("")| !password.equalsIgnoreCase("")
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
                String sql = "select * from provider where emailid='"+username+"' and password='"+password+"'";
                rs = stm.executeQuery(sql);

                int userId = 0;
                while (rs.next()) {
                    userId = rs.getInt("id");

                    user.accumulate("status", "ok");
                    user.accumulate("time", System.currentTimeMillis());
                    user.accumulate("user_id", userId);
                    user.accumulate("first_name",rs.getString("firstname"));
                    user.accumulate("last_name",rs.getString("lastname"));
                    user.accumulate("email",rs.getString("emailid"));
                    user.accumulate("company_name",rs.getString("companyname"));
//                    user.accumulate("address",rs.getString("address"));
//                    user.accumulate("date_of_birth",rs.getString("dateofbirth"));
//                    user.accumulate("gender",rs.getString("gender"));
//                    user.accumulate("usertype",rs.getInt("usertype"));

                }
                rs.close();
                
            }catch(SQLException e){
                e.printStackTrace();
                user.accumulate("status", "error");
                user.accumulate("message", "Please check your details and try again.");
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }finally{
                
                stm.close();
                con.close();
            }
        }else{
            user.accumulate("status", "error");
        }
        return user.toString();
    }
    @GET
    @Path("login1&{username}&{password}")
    @Produces("application/json")
    //@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String login1(@PathParam("username") String username, @PathParam("password") String password) throws SQLException, JSONException{
        JSONObject user = new JSONObject();
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
        System.out.println("username: "+username+"  password: "+password);
            if(username!="" | password.trim()!=""){
            //username!=null | password!=null !username.equalsIgnoreCase("")| !password.equalsIgnoreCase("")
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
                String sql = "select * from finder where email='"+username+"' and password='"+password+"'";
                rs = stm.executeQuery(sql);

                int userId = 0;
                while (rs.next()) {
                    userId = rs.getInt("id");

                    user.accumulate("status", "ok");
                    user.accumulate("time", System.currentTimeMillis());
                    user.accumulate("user_id", userId);
                    user.accumulate("first_name",rs.getString("firstname"));
                    user.accumulate("last_name",rs.getString("lastname"));
                    user.accumulate("email",rs.getString("email"));
                  
//                    user.accumulate("address",rs.getString("address"));
//                    user.accumulate("date_of_birth",rs.getString("dateofbirth"));
//                    user.accumulate("gender",rs.getString("gender"));
//                    user.accumulate("usertype",rs.getInt("usertype"));

                }
                rs.close();
                
            }catch(SQLException e){
                e.printStackTrace();
                user.accumulate("status", "error");
                user.accumulate("message", "Please check your details and try again.");
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }finally{
                
                stm.close();
                con.close();
            }
        }else{
            user.accumulate("status", "error");
        }
        return user.toString();
    }
    @GET
    @Path("register&{email}&{fname}&{lname}&{cname}&{password}")
    @Produces("application/json")
    //@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String register(@PathParam("email") String email, @PathParam("fname") String fname,
            @PathParam("lname") String lname, @PathParam("cname") String cname,
            @PathParam("password") String password) throws SQLException, JSONException{
        JSONObject user1 = new JSONObject();
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
        int insertCount = 0;
        System.out.println("email: "+email+"  fname: "+fname
        +"  lname: "+lname+"  cname: "+cname+"  password: "+password);
            if(email!="" && password!=""){
            //username!=null | password!=null !username.equalsIgnoreCase("")| !password.equalsIgnoreCase("")
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
                long pk = getPK("PROVIDER", "ID");
                String sql = "INSERT INTO PROVIDER(ID, EMAILID, FIRSTNAME, LASTNAME,PASSWORD,COMPANYNAME) "+
                        "VALUES ("+pk+", '"+email+"', '"+fname+"', '"+lname+"', '"+password+"', '"+cname+"') ";
                //String sql = "select * from finder where email='"+username+"' and password='"+password+"'";
                System.out.println("sql: "+sql);
                insertCount = stm.executeUpdate(sql);
                
                if(insertCount == 1){
                    user1.accumulate("status", "ok");
                    user1.accumulate("message", "Registered successfully.");
                }
            }catch(SQLException e){
                e.printStackTrace();
                user1.accumulate("status", "error");
                user1.accumulate("message", "Please check your details and try again.");
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }finally{
                
                stm.close();
                con.close();
            }
        }else{
            user1.accumulate("status", "error");
            user1.accumulate("message", "Please enter email and/or password.");
        }
            System.out.println("return string: "+user1.toString());
        return user1.toString();
    }
    
    @POST
    @Path("/registerpost")
    @Produces("application/json")
    //@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String registerPost(@FormParam("email") String email, @FormParam("firstname") String firstname,@FormParam("lastname") String lastname,@FormParam("password") String password,@FormParam("companyname") String companyname){
        String result="false";
		int x = 0;
            try{
                Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
            Statement stm = con.createStatement();
               PreparedStatement ps = con.prepareStatement("insert into provider(emailid,firstname,lastname, password,companyname) values(?,?)");
			ps.setString(1, email);
			ps.setString(2, firstname);
                        ps.setString(3, lastname);
                        ps.setString(4, password);
                        ps.setString(5, companyname);
			
			x = ps.executeUpdate();
			
			if(x==1){
				result = "true";
			}
			
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return result;
	}
    
    private long getPK (String tableName, String columnName) throws SQLException{
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
        long pk = 1;
        //username!=null | password!=null !username.equalsIgnoreCase("")| !password.equalsIgnoreCase("")
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
                String sql = "select "+columnName+" from "+tableName+" ORDER BY "+columnName+" DESC";
                rs = stm.executeQuery(sql);

                if(rs.next()==true){
                    pk = rs.getLong("ID");
                    pk+=1;
                }
                
                rs.close();
            }catch(SQLException e){
                e.printStackTrace();
                
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }finally{
                
                stm.close();
                con.close();
            }
        
        return pk;
    }
    @GET
    @Path("register1&{email}&{fname}&{lname}&{dateofbirth}&{password}")
    @Produces("application/json")
    //@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String register1(@PathParam("email") String email, @PathParam("fname") String fname,
            @PathParam("lname") String lname, @PathParam("dateofbirth") String dateofbirth,
            @PathParam("password") String password) throws SQLException, JSONException{
        JSONObject user1 = new JSONObject();
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
        int insertCount = 0;
        System.out.println("email: "+email+"  fname: "+fname
        +"  lname: "+lname+"  dateofbirth: "+dateofbirth+"  password: "+password);
            if(email!="" && password!=""){
            //username!=null | password!=null !username.equalsIgnoreCase("")| !password.equalsIgnoreCase("")
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
                long pk1 = getPK1("FINDER", "ID");
                String sql = "INSERT INTO FINDER(ID, EMAIL, FIRSTNAME, LASTNAME,PASSWORD,DATEOFBIRTH) "+
                        "VALUES ("+pk1+", '"+email+"', '"+fname+"', '"+lname+"', '"+password+"', '"+dateofbirth+"') ";
                //String sql = "select * from finder where email='"+username+"' and password='"+password+"'";
                System.out.println("sql: "+sql);
                insertCount = stm.executeUpdate(sql);
                
                if(insertCount == 1){
                    user1.accumulate("status", "ok");
                    user1.accumulate("message", "Registered successfully.");
                }
            }catch(SQLException e){
                e.printStackTrace();
                user1.accumulate("status", "error");
                user1.accumulate("message", "Please check your details and try again.");
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }finally{
                
                stm.close();
                con.close();
            }
        }else{
            user1.accumulate("status", "error");
            user1.accumulate("message", "Please enter email and/or password.");
        }
            System.out.println("return string: "+user1.toString());
        return user1.toString();
    }
      private long getPK1 (String tableName, String columnName) throws SQLException{
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
        long pk1 = 1;
        //username!=null | password!=null !username.equalsIgnoreCase("")| !password.equalsIgnoreCase("")
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
                String sql = "select "+columnName+" from "+tableName+" ORDER BY "+columnName+" DESC";
                rs = stm.executeQuery(sql);

                if(rs.next()==true){
                    pk1 = rs.getLong("ID");
                    pk1+=1;
                }
                
                rs.close();
            }catch(SQLException e){
                e.printStackTrace();
                
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }finally{
                
                stm.close();
                con.close();
            }
        
        return pk1;
    }
    @GET
    @Path("post&{email}&{companyname}&{title}&{description}&{address}&{salary}")
    @Produces("application/json")
    //@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String post(@PathParam("email") String email,@PathParam("companyname") String companyname, @PathParam("title") String title, @PathParam("description") String description, @PathParam("address") String address,@PathParam("salary") Long salary) throws SQLException, JSONException{
        JSONObject user1 = new JSONObject();
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
        int insertCount = 0;
        System.out.println("email: "+email+" companyname: "+companyname+"  title: "+title+" description: "+description+" address: "+address+" salary: "+salary);
            if(email!="" && companyname!="" && title!=""&& description!=""&&  address!=""){
            //username!=null | password!=null !username.equalsIgnoreCase("")| !password.equalsIgnoreCase("")
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
                long pk3 = getPK3("POSTJOB", "ID");
             
                String sql = "INSERT INTO POSTJOB(ID, EMAIL,COMPANYNAME,TITLE,DESCRIPTION,ADDRESS,SALARY) "+
                        "VALUES ("+pk3+"','"+email+"','"+companyname+"','"+title+"', '"+description+"','"+address+"','"+salary+"') ";
                //String sql = "select * from finder where email='"+username+"' and password='"+password+"'";
                System.out.println("sql: "+sql);
                insertCount = stm.executeUpdate(sql);
                
                if(insertCount == 1){
                    user1.accumulate("status", "ok");
                    user1.accumulate("message", "Registered successfully.");
                }
            }catch(SQLException e){
                e.printStackTrace();
                user1.accumulate("status", "error");
                user1.accumulate("message", "Please check your details and try again.");
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }finally{
                
                stm.close();
                con.close();
            }
        }else{
            user1.accumulate("status", "error");
            user1.accumulate("message", "Please enter email and/or password.");
        }
            System.out.println("return string: "+user1.toString());
        return user1.toString();
    }
      private long getPK3 (String tableName, String columnName) throws SQLException{
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
        long pk3 = 1;
        //username!=null | password!=null !username.equalsIgnoreCase("")| !password.equalsIgnoreCase("")
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
                String sql = "select "+columnName+" from "+tableName+" ORDER BY "+columnName+" DESC";
                rs = stm.executeQuery(sql);

                if(rs.next()==true){
                    pk3 = rs.getLong("ID");
                    pk3+=1;
                }
                
                rs.close();
            }catch(SQLException e){
                e.printStackTrace();
                
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }finally{
                
                stm.close();
                con.close();
            }
        
        return pk3;
    }
     
    @GET
    @Path("resume&{email}&{fname}&{lname}&{experience}&{company}&{city}&{education}")
    @Produces("application/json")
    //@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String resume(@PathParam("email") String email, @PathParam("fname") String fname,
            @PathParam("lname") String lname, @PathParam("experience") String experience,
             @PathParam("company") String company, @PathParam("city") String city,@PathParam("education") String education) throws SQLException, JSONException{
        JSONObject user1 = new JSONObject();
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
        int insertCount = 0;
        System.out.println("email: "+email+"  fname: "+fname
        +"  lname: "+lname+"  experience: "+experience+"  company: "+company+" city: "+city+" education: "+education);
            if(email!="" && fname!=""){
            //username!=null | password!=null !username.equalsIgnoreCase("")| !password.equalsIgnoreCase("")
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
                long pk4 = getPK4("RESUME", "ID");
                String sql = "INSERT INTO RESUME(ID, EMAIL, FIRSTNAME, LASTNAME,EXPERIENCE,COMPANY,CITY,EDUCATION) "+
                        "VALUES ("+pk4+", '"+email+"', '"+fname+"', '"+lname+"', '"+experience+"', '"+company+"','"+city+"','"+education+"') ";
                //String sql = "select * from finder where email='"+username+"' and password='"+password+"'";
                System.out.println("sql: "+sql);
                insertCount = stm.executeUpdate(sql);
                
                if(insertCount == 1){
                    user1.accumulate("status", "ok");
                    user1.accumulate("message", "Registered successfully.");
                }
            }catch(SQLException e){
                e.printStackTrace();
                user1.accumulate("status", "error");
                user1.accumulate("message", "Please check your details and try again.");
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }finally{
                
                stm.close();
                con.close();
            }
        }else{
            user1.accumulate("status", "error");
            user1.accumulate("message", "Please enter email and/or password.");
        }
            System.out.println("return string: "+user1.toString());
        return user1.toString();
    }
    private long getPK4 (String tableName, String columnName) throws SQLException{
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
        long pk4 = 0;
        //username!=null | password!=null !username.equalsIgnoreCase("")| !password.equalsIgnoreCase("")
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
                String sql = "select "+columnName+" from "+tableName+" ORDER BY "+columnName+" DESC";
                rs = stm.executeQuery(sql);

                if(rs.next()==true){
                    pk4 = rs.getLong("ID");
                    pk4+=1;
                }
                
                rs.close();
            }catch(SQLException e){
                e.printStackTrace();
                
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }finally{
                
                stm.close();
                con.close();
            }
        
        return pk4;
    }
    @GET
    @Path("/viewfinder")
    @Produces("application/json")
    //@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String viewfinder(@PathParam("username") String username, @PathParam("password") String password) throws SQLException, JSONException{
        JSONObject user = new JSONObject();
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
        System.out.println("username: "+username+"  password: "+password);
            if(username!="" | password.trim()!=""){
            //username!=null | password!=null !username.equalsIgnoreCase("")| !password.equalsIgnoreCase("")
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
                String sql = "select ID,EMAIL,FIRSTNAME,LASTNAME,DATEOFBIRTH from FINDER";
                rs = stm.executeQuery(sql);

                int userId = 0;
                while (rs.next()) {
                    userId = rs.getInt("id");

                    user.accumulate("status", "ok");
                    user.accumulate("time", System.currentTimeMillis());
                    user.accumulate("user_id", userId);
                    user.accumulate("first_name",rs.getString("firstname"));
                    user.accumulate("last_name",rs.getString("lastname"));
                    user.accumulate("email",rs.getString("emailid"));
                    user.accumulate("company_name",rs.getString("companyname"));
//                    user.accumulate("address",rs.getString("address"));
//                    user.accumulate("date_of_birth",rs.getString("dateofbirth"));
//                    user.accumulate("gender",rs.getString("gender"));
//                    user.accumulate("usertype",rs.getInt("usertype"));

                }
                rs.close();
                
            }catch(SQLException e){
                e.printStackTrace();
                user.accumulate("status", "error");
                user.accumulate("message", "Please check your details and try again.");
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }finally{
                
                stm.close();
                con.close();
            }
        }else{
            user.accumulate("status", "error");
        }
        return user.toString();
    }
    
   @GET
    @Path("getAllJobProviderData")
    @Produces("application/json")
    //@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String getAllJobProviderData() throws SQLException, JSONException{
        JSONObject object = new JSONObject();
       
       
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
          
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
               
                String sql = "select COMPANYNAME, TITLE, SALARY from POSTJOB order by POSTJOB.SALARY DESC";
               
                rs = stm.executeQuery(sql);
               
                if(rs.next()==true){
                   
                    JSONArray jobs = new JSONArray();
                    do {
                        JSONObject job = new JSONObject();
                        job.accumulate("companyName", rs.getString("COMPANYNAME"));
                        job.accumulate("title", rs.getString("TITLE"));
                        job.accumulate("salary", rs.getLong("SALARY"));
                        jobs.put(job);
                    } while (rs.next());
                    object.accumulate("jobs", jobs);
                    object.accumulate("status", "ok");
                    object.accumulate("message","Featched up successfully.");
                }else{
                    object.accumulate("status", "error");
                    object.accumulate("message", "Please try again.");
                }
              
                rs.close();
               
            }catch(SQLException e){
                e.printStackTrace();
                object.accumulate("status", "error");
                object.accumulate("message", "Please try again.");
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }
            finally{
                stm.close();
                con.close();
            }
       
        return object.toString();
    }
   @GET
    @Path("viewfinders")
    @Produces("application/json")
    //@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String viewfinders() throws SQLException, JSONException{
        JSONObject object = new JSONObject();
       
       
        Statement stm = null;
        Connection con = null;
        ResultSet rs = null;
          
            try{
                Class.forName("oracle.jdbc.OracleDriver");
                con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "a19madteam6", "anypw");
                stm = con.createStatement();
               
                String sql = "select EMAIL, FIRSTNAME, LASTNAME,DATEOFBIRTH from FINDER";
               
                rs = stm.executeQuery(sql);
               
                if(rs.next()==true){
                   
                    JSONArray users = new JSONArray();
                    do {
                        JSONObject user = new JSONObject();
                        user.accumulate("EmailId", rs.getString("EMAIL"));
                        user.accumulate("FirstName", rs.getString("FIRSTNAME"));
                        user.accumulate("Lastname", rs.getLong("LASTNAME"));
                        user.accumulate("DateOfBirth", rs.getLong("DATEOFBIRTH"));
                        users.put(user);
                    } while (rs.next());
                    object.accumulate("users", users);
                    object.accumulate("status", "ok");
                    object.accumulate("message","Fetched up successfully.");
                }else{
                    object.accumulate("status", "error");
                    object.accumulate("message", "Please try again.");
                }
              
                rs.close();
               
            }catch(SQLException e){
                e.printStackTrace();
                object.accumulate("status", "error");
                object.accumulate("message", "Please try again.");
            }catch(ClassNotFoundException e){
                e.printStackTrace();
            }
            finally{
                stm.close();
                con.close();
            }
       
        return object.toString();
    }
 
    
    @POST
    @Path("changePassword")
    @Produces("application/json")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String changePassword(@FormParam("oldPassword") long oldPassword, @FormParam("newPassword") String newPassword) throws SQLException, JSONException {
       
        JSONObject changePassword = new JSONObject();
        Statement stmt = null;
        Connection con = null;
        ResultSet rs = null;
        int imageCount = 0;
        int levelCount = 0;
        long imageId = 0;
        int duplicateCount = 0;
     
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "A19MADTEAM6", "anypw");
            stmt = con.createStatement();
           
            String sql = "SELECT password FROM PROVIDER WHERE PASSWORD = '"+oldPassword+"'";
            duplicateCount = stmt.executeUpdate(sql);
            //DUPLICAT
            if(duplicateCount==1){
           
                //update
                
                    sql = "UPDATE PROVIDER SET password = '"+newPassword+"' where password='"+oldPassword+"'";
                    levelCount = stmt.executeUpdate(sql);
                    if(levelCount==1){
                        changePassword.accumulate("status", "ok");
                        changePassword.accumulate("message","password has been updated successfully.");
                    }
                
            }else{
                changePassword.accumulate("status", "error");
                changePassword.accumulate("message", "No such user with this password.");
            }
        }catch(SQLException e){
            e.printStackTrace();
            changePassword.accumulate("status", "error");
            changePassword.accumulate("message", "Please check details and try again.");
        }catch(ClassNotFoundException e){
            //Logger.getLogger(LangExpoWS.class.getName()).log(Level.SEVERE, null, e);
        }finally{
            stmt.close();
            con.close();
        }
       
        return changePassword.toString();
    }

    /**
     *
     * @param oldPassword
     * @param newPassword
     * @return
     * @throws SQLException
     * @throws JSONException
     */
    @POST
    @Path("changePasswordd")
    @Produces("application/json")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String changePasswordd(@FormParam("oldPassword") long oldPassword, @FormParam("newPassword") String newPassword) throws SQLException, JSONException {
       
        JSONObject changePasswordd = new JSONObject();
        Statement stmt = null;
        Connection con = null;
        ResultSet rs = null;
        int imageCount = 0;
        int levelCount = 0;
        long imageId = 0;
        int duplicateCount = 0;
     
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "A19MADTEAM6", "anypw");
            stmt = con.createStatement();
           
            String sql = "SELECT password FROM PROVIDER WHERE PASSWORD = '"+oldPassword+"'";
            duplicateCount = stmt.executeUpdate(sql);
            //DUPLICAT
            if(duplicateCount==1){
           
                //update
                
                    sql = "UPDATE PROVIDER SET password = '"+newPassword+"' where password='"+oldPassword+"'";
                    levelCount = stmt.executeUpdate(sql);
                    if(levelCount==1){
                        changePasswordd.accumulate("status", "ok");
                        changePasswordd.accumulate("message","password has been updated successfully.");
                    }
                
            }else{
                changePasswordd.accumulate("status", "error");
                changePasswordd.accumulate("message", "No such user with this password.");
            }
        }catch(SQLException e){
            e.printStackTrace();
            changePasswordd.accumulate("status", "error");
            changePasswordd.accumulate("message", "Please check details and try again.");
        }catch(ClassNotFoundException e){
            //Logger.getLogger(LangExpoWS.class.getName()).log(Level.SEVERE, null, e);
        }finally{
            stmt.close();
            con.close();
        }
       
        return changePasswordd.toString();
    }
    @POST
    @Path("changeProfileP")
    @Produces("application/json")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String changeProfileP(@FormParam("emailid") long emailid,@FormParam("firstname") String firstname,@FormParam("lastname") String lastname) throws SQLException, JSONException {
       
        JSONObject addUpdateProfile = new JSONObject();
        Statement stmt = null;
        Connection con = null;
        ResultSet rs = null;
        int imageCount = 0;
        int profile = 0;
        long imageId = 0;
        int duplicateCount = 0;
     
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "A19MADTEAM6", "anypw");
            stmt = con.createStatement();
           
            String sql = "SELECT FIRSTNAME,LASTNAME,EMAILID FROM PROVIDER WHERE EMAILID = '"+emailid;
            duplicateCount = stmt.executeUpdate(sql);
            //DUPLICAT
            if(duplicateCount==1){
           
                //update
                
                    sql = "UPDATE PROVIDER SET FIRSTNAME = '"+firstname+"',LASTNAME='"+lastname+"' where EMAILID='"+emailid+"'";
                    profile = stmt.executeUpdate(sql);
                    if(profile==1){
                        addUpdateProfile.accumulate("status", "ok");
                        addUpdateProfile.accumulate("message","profile has been updated successfully.");
                    }
                
            }else{
                addUpdateProfile.accumulate("status", "error");
                addUpdateProfile.accumulate("message", "No such user with this emailId.");
            }
        }catch(SQLException e){
            e.printStackTrace();
            addUpdateProfile.accumulate("status", "error");
            addUpdateProfile.accumulate("message", "Please check details and try again.");
        }catch(ClassNotFoundException e){
            //Logger.getLogger(LangExpoWS.class.getName()).log(Level.SEVERE, null, e);
        }finally{
            stmt.close();
            con.close();
        }
       
        return addUpdateProfile.toString();
    }
}
  
   

 