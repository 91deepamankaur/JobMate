package com.example.jobmate;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;

public class changepasswordf extends AppCompatActivity {

    EditText oldPasswordET, newPasswordET, confirmNewPasswordET;
    String oldPassword, newPassword, confirmNewPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changepasswordf);
        oldPasswordET = (EditText)findViewById(R.id.password);
        newPasswordET = (EditText)findViewById(R.id.npassword);
        confirmNewPasswordET = (EditText)findViewById(R.id.rpassword);


    }

    public void changePassword(View view) {
        oldPassword = oldPasswordET.getText().toString();
        newPassword = newPasswordET.getText().toString();
        confirmNewPassword = confirmNewPasswordET.getText().toString();

        //validation
        if(oldPassword.trim().equalsIgnoreCase("")){
            oldPasswordET.setError("please enter current password");
            oldPasswordET.requestFocus();
            oldPasswordET.setText("");
            return;
        }
        if(newPassword.trim().equalsIgnoreCase("")){
            newPasswordET.setError("please enter new password.");
            newPasswordET.requestFocus();
            newPasswordET.setText("");
            return;
        }
        if(confirmNewPassword.trim().equalsIgnoreCase("")){
            confirmNewPasswordET.setError("please enter confirm password.");
            confirmNewPasswordET.requestFocus();
            confirmNewPasswordET.setText("");
            return;
        }if(!newPassword.trim().equalsIgnoreCase(confirmNewPassword.trim())){
            confirmNewPasswordET.setError("password and confirm password should be same.");
            confirmNewPasswordET.requestFocus();
            confirmNewPasswordET.setText("");
            return;
        }
        //validation end
        new ChangePasswordAsyncTask(changepasswordf.this, oldPassword, newPassword).execute();
    }



    private class ChangePasswordAsyncTask extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressBar;
        private String oldPassword;
        private String newPassword;

        public ChangePasswordAsyncTask(Activity activity, String oldPassword,
                                 String newPassword){
            progressBar = new ProgressDialog(activity);
            this.oldPassword = oldPassword;
            this.newPassword = newPassword;
        }

        protected void onPreExecute(){
            progressBar.setMessage("Loading...");
            progressBar.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            URL url = null;
            BufferedReader reader = null;
            StringBuilder stringBuilder = new StringBuilder();

            try {
                String urlParameters = "oldPassword="+oldPassword+"&newPassword="+newPassword;

                byte[] postData = urlParameters.getBytes();
                int postDataLength = postData.length;
                url = new URL("http://10.0.2.2:8080/Web_Application/webresources/mobile/changePassword");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setDoInput(true);
                connection.setInstanceFollowRedirects(false);
                connection.setRequestProperty("charset","utf-8");
                connection.setRequestProperty("Content-Length",Integer.toString(postDataLength));
                connection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
                connection.setUseCaches( false );
                // give it 15 seconds to respond
                connection.setReadTimeout(15*1000);
                connection.setConnectTimeout(15*1000);
                connection.connect();
                try( DataOutputStream wr = new DataOutputStream( connection.getOutputStream())) {
                    wr.write( postData );
                }

                connection.connect();

                // read the output from the server
                stringBuilder = new StringBuilder();
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }

                System.out.println("response: "+stringBuilder.toString());
            }
            catch (Exception e) {

                e.printStackTrace();
                try {
                    throw e;
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            finally {
                if (reader != null) {
                    try{
                        reader.close();
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return stringBuilder.toString();
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            System.out.println(result);
            try {
                JSONObject loginResponse = new JSONObject(result);
                if(loginResponse.length()!=0 &&
                        loginResponse.get("status").toString().equalsIgnoreCase("ok") ) {

                    Toast toast = Toast.makeText(changepasswordf.this,loginResponse.get("message").toString(),Toast.LENGTH_LONG);
                    Intent intent = new Intent(changepasswordf.this, loginFinder.class);
                    startActivity(intent);
                    progressBar.dismiss();
                    toast.show();
                }
                else if(loginResponse.get("status").toString().equalsIgnoreCase("error")){

                    Toast toast = Toast.makeText(changepasswordf.this,loginResponse.get("message").toString(),Toast.LENGTH_LONG);
                    progressBar.dismiss();
                    toast.show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
    public void Back(View view) {
        Intent intent=new Intent(changepasswordf.this,ModifyProfileFinder.class);
        startActivity(intent);
    }

}
