package com.example.jobmate;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class loginFinder extends AppCompatActivity {
    EditText emailET, passwordET;
    String email, password;
    EditText e1, e2;
    private Button button;
    private Button button1;
    private Button forgotpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_finder);
        emailET = (EditText) findViewById(R.id.e1);
        passwordET = (EditText) findViewById(R.id.e2);
        button = (Button) findViewById(R.id.login);
        button1 = (Button) findViewById(R.id.save);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(loginFinder.this, registerFinder.class);
                startActivity(intent);
            }
        });
    }

    public void Login(View view) {
        email = emailET.getText().toString();
        password = passwordET.getText().toString();
        //validation start

        if (email.equalsIgnoreCase("")) {
            emailET.setError("Please enter email");
            emailET.requestFocus();
            return;
        }
        if (password.equalsIgnoreCase("")) {
            passwordET.setError("Please enter password");
            passwordET.requestFocus();
            return;
        }
        new Login(loginFinder.this, email,
                password).execute();
    }

    public void Back(View view) {
        Intent intent=new Intent(loginFinder.this,MainActivity.class);
        startActivity(intent);
    }

    private class Login extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressBar;
        private String username;
        private String password;

        public Login(Activity activity, String username, String password) {
            progressBar = new ProgressDialog(activity);
            this.username = username;
            this.password = password;
        }

        protected void onPreExecute() {
            progressBar.setMessage("Loading...");
            progressBar.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            URL url = null;
            BufferedReader reader = null;
            StringBuilder stringBuilder = new StringBuilder();

            try {
                url = new URL("http://" + Constant.WEB_SERVICE_HOST + ":" + Constant.WEB_SERVICE_PORT + "/Web_Application/webresources/mobile/login1&"+username+"&"+password);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                // uncomment this if you want to write output to this url

                connection.setDoInput(true);
                connection.setInstanceFollowRedirects(false);

                // give it 15 seconds to respond
                connection.setReadTimeout(15 * 1000);
                connection.connect();
                // read the output from the server
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }

                System.out.println("url: " + stringBuilder.toString());
            } catch (Exception e) {
                e.printStackTrace();
                try {
                    throw e;
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return stringBuilder.toString();
        }

        @Override

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            System.out.println(result);
            try {
                JSONObject loginResponse = new JSONObject(result);
                if (loginResponse.length() != 0 &&
                        loginResponse.get("status").toString().equalsIgnoreCase("ok") &&
                        !loginResponse.get("user_id").toString().equalsIgnoreCase("")) {
                    long userId = Long.parseLong(loginResponse.get("user_id").toString());
                    String email = loginResponse.get("email").toString();
                    String firstname = loginResponse.get("first_name").toString();
                    String lastname = loginResponse.get("last_name").toString();

                    Intent intent = new Intent(loginFinder.this, ProfileFinder.class);
                    startActivity(intent);
                    progressBar.dismiss();
                } else {
                    Toast toast = Toast.makeText(getApplicationContext(), "Please enter correct credentials", Toast.LENGTH_LONG);
                    emailET.setText("");
                    emailET.requestFocus();
                    passwordET.setText("");
                    progressBar.dismiss();
                    toast.show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

