package com.example.jobmate;

public class Model {
    public String companyName;
    public String jobType;
    public long salary;
    public Model(String companyName, String jobType, long salary) {
        super();
        this.companyName = companyName;
        this.jobType = jobType;
        this.salary = salary;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public long getSalary() {
        return salary;
    }

    public void setSalary(long salary) {
        this.salary = salary;
    }
}
