package com.example.jobmate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class profilepro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profilepro);

    }

    public void home(View view) {
        Intent intent = new Intent(profilepro.this, MainActivity.class);
        startActivity(intent);
    }

    public void profile(View view) {
        Intent intent = new Intent(profilepro.this, ModifyProfileProvider.class);
        startActivity(intent);
    }

    public void add(View view) {
        Intent intent = new Intent(profilepro.this, PostJob.class);
        startActivity(intent);
    }
    public void postjobs(View view) {
        Intent intent=new Intent(profilepro.this,PostJob.class);
        startActivity(intent);
    }

    public void viewfinders(View view) {
        Intent intent=new Intent(profilepro.this,FindersList.class);
        startActivity(intent);
    }

    public void viewappliedjobs(View view) {
        Intent intent=new Intent(profilepro.this,PostedJobs.class);
        startActivity(intent);
    }
}
