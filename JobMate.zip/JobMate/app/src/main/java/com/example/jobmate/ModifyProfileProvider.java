package com.example.jobmate;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ModifyProfileProvider extends AppCompatActivity {
    private Button button,button2;

    EditText emailidET, firstnameET, lastnameET;
    String emailid, firstname, lastname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_profile_provider);

        emailidET = (EditText)findViewById(R.id.emailid);
        firstnameET = (EditText)findViewById(R.id.fname);
        lastnameET = (EditText)findViewById(R.id.lname);
        button=(Button)findViewById(R.id.chngpass);
        button2=(Button)findViewById(R.id.logout);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ModifyProfileProvider.this,changepasswordP.class);
                startActivity(intent);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ModifyProfileProvider.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }

    public void save(View view) {
        emailid = emailidET.getText().toString();
        firstname = firstnameET.getText().toString();
        lastname = lastnameET.getText().toString();
        //validation
        if (emailid.equalsIgnoreCase("")) {
            emailidET.setError("Please enter email");
            emailidET.requestFocus();
            return;
        }
        if (firstname.equalsIgnoreCase("")) {
            firstnameET.setError("Please enter first name");
            firstnameET.requestFocus();
            return;
        }
        if (lastname.equalsIgnoreCase("")) {
            lastnameET.setError("Please enter last name");
            lastnameET.requestFocus();
            return;
        }
        //validation end
        new modifyProfile(ModifyProfileProvider.this, emailid, firstname,lastname).execute();
    }

    public void Back(View view) {
        Intent intent=new Intent(ModifyProfileProvider.this,profilepro.class);
        startActivity(intent);
    }

    public void about(View view) {

    Intent intent=new Intent(ModifyProfileProvider.this,About.class);
    startActivity(intent);
}

    public void added(View view) {

        Intent intent=new Intent(ModifyProfileProvider.this,PostJob.class);
        startActivity(intent);
    }

    public void home(View view) {
        Intent intent=new Intent(ModifyProfileProvider.this,MainActivity.class);
        startActivity(intent);
    }

    public void search(View view) {
        Intent intent=new Intent(ModifyProfileProvider.this,search.class);
        startActivity(intent);
    }

    public void logout(View view) {
        Intent intent=new Intent(ModifyProfileProvider.this,MainActivity.class);
        startActivity(intent);
    }

    public void postjob(View view) {
        Intent intent=new Intent(ModifyProfileProvider.this,PostJob.class);
        startActivity(intent);
    }

    private class modifyProfile extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressBar;
        private String emailid;
        private String firstname;
        private String lastname;

        public modifyProfile(Activity activity, String emailid,
                                       String firstname,String lastname){
            progressBar = new ProgressDialog(activity);
            this.emailid = emailid;
            this.firstname = firstname;
            this.lastname = lastname;
        }

        protected void onPreExecute(){
            progressBar.setMessage("Loading...");
            progressBar.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            URL url = null;
            BufferedReader reader = null;
            StringBuilder stringBuilder = new StringBuilder();

            try {
                String urlParameters = "emailid="+emailid+"&firstname="+firstname+"&lastname="+lastname;

                byte[] postData = urlParameters.getBytes();
                int postDataLength = postData.length;
                url = new URL("http://10.0.2.2:8080/Web_Application/webresources/mobile/changeProfileP");
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                // uncomment this if you want to write output to this url
                connection.setDoOutput(true);
                connection.setDoInput(true);
                connection.setInstanceFollowRedirects( false );
                connection.setRequestProperty( "charset", "utf-8");
                connection.setRequestProperty( "Content-Length", Integer.toString( postDataLength ));
                connection.setRequestProperty( "Content-Type", "application/x-www-form-urlencoded");
                connection.setUseCaches( false );
                // give it 15 seconds to respond
                connection.setReadTimeout(15*1000);
                connection.setConnectTimeout(15*1000);
                try( DataOutputStream wr = new DataOutputStream( connection.getOutputStream())) {
                    wr.write( postData );
                }

                connection.connect();

                // read the output from the server
                stringBuilder = new StringBuilder();
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }

                System.out.println("response: "+stringBuilder.toString());
            }
            catch (Exception e) {

                e.printStackTrace();
                try {
                    throw e;
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            finally {
                if (reader != null) {
                    try{
                        reader.close();
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return stringBuilder.toString();
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            System.out.println(result);
            try {
                JSONObject loginResponse = new JSONObject(result);
                if(loginResponse.length()!=0 &&
                        loginResponse.get("status").toString().equalsIgnoreCase("ok") ) {

                    Toast toast = Toast.makeText(ModifyProfileProvider.this,loginResponse.get("message").toString(),Toast.LENGTH_LONG);
                    Intent intent = new Intent(ModifyProfileProvider.this, loginFinder.class);
                    startActivity(intent);
                    progressBar.dismiss();
                    toast.show();
                }
                else if(loginResponse.get("status").toString().equalsIgnoreCase("error")){

                    Toast toast = Toast.makeText(ModifyProfileProvider.this,loginResponse.get("message").toString(),Toast.LENGTH_LONG);
                    progressBar.dismiss();
                    toast.show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
