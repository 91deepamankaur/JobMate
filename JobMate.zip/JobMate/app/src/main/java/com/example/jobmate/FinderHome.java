package com.example.jobmate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;

public class FinderHome extends AppCompatActivity implements
        SenderFragment.SenderFragmentListener{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finder_home);
    }

    @Override
    public void messageFromSenderFragment(String msg) {
        FragmentManager manager = getSupportFragmentManager();
        ReceiverFragment mReceiverFragment = (ReceiverFragment)manager.findFragmentById(R.id.frg_Receiver);
        mReceiverFragment.youGotMsg(msg);
    }

}
