package com.example.jobmate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ModifyProfileFinder extends AppCompatActivity {
    private Button button,button1,button2,button3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_profile_finder);
        button=(Button)findViewById(R.id.chngpass);
        button1=(Button)findViewById(R.id.UploadResume);
        button2=(Button)findViewById(R.id.Search);
        button3=(Button)findViewById(R.id.logout);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ModifyProfileFinder.this,changepasswordf.class);
                startActivity(intent);
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ModifyProfileFinder.this,Resume.class);
                startActivity(intent);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ModifyProfileFinder.this,search.class);
                startActivity(intent);
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ModifyProfileFinder.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }

    public void Back(View view) {
        Intent intent=new Intent(ModifyProfileFinder.this,profilefind.class);
        startActivity(intent);
    }

    public void logout(View view) {
        Intent intent=new Intent(ModifyProfileFinder.this,MainActivity.class);
        startActivity(intent);
    }

    public void home(View view) {
        Intent intent=new Intent(ModifyProfileFinder.this,MainActivity.class);
        startActivity(intent);
    }

    public void about(View view) {
            Intent intent=new Intent(ModifyProfileFinder.this,About.class);
            startActivity(intent);
    }

    public void saved(View view) {
        Intent intent=new Intent(ModifyProfileFinder.this,AppliedJobF.class);
        startActivity(intent);
    }

    public void search(View view) {
        Intent intent=new Intent(ModifyProfileFinder.this,search.class);
        startActivity(intent);
    }

    public void modifyAdded(View view) {
        Intent intent=new Intent(ModifyProfileFinder.this,ModifyPostJobs.class);
        startActivity(intent);
    }
}
