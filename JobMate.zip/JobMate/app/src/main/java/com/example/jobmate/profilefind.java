package com.example.jobmate;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.google.android.material.snackbar.Snackbar;

import java.util.Arrays;

public class profilefind extends AppCompatActivity {
    private Activity mActivity;
    private CoordinatorLayout mCLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profilefind);
        mActivity = profilefind.this;
        // Get the widget reference from XML layout mCLayout = (CoordinatorLayout) findViewById(R.id.coordinator_layout);

    }

    public void home(View view) {
        Intent intent = new Intent(profilefind.this, MainActivity.class);
        startActivity(intent);
    }
    public void search(View view) {
        Intent intent = new Intent(profilefind.this, search.class);
        startActivity(intent);
    }
    public void profile(View view) {
        Intent intent = new Intent(profilefind.this, ModifyProfileFinder.class);
        startActivity(intent);
    }

    public void Back(View view) {
        Intent intent=new Intent(profilefind.this,MainActivity.class);
        startActivity(intent);
    }

    public void applied(View view) {
        Intent intent=new Intent(profilefind.this,AppliedJobF.class);
        startActivity(intent);
    }

   /* public void search(View view) {
        Intent intent = new Intent(profilefind.this, search.class);
        startActivity(intent);
    }*/

}