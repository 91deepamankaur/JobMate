package com.example.jobmate;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PostJob extends AppCompatActivity {
    private static final String TAG = "PostJob";
    private TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private Button button;
    private Button button1;
    EditText emailidET, companynameET, titleET, descriptionET, addressET, salaryET;
    String emailid, companyname, title, description, address,salary;
    Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_job);

        emailidET = findViewById(R.id.emailid);
        companynameET = findViewById(R.id.companyname);
        titleET = findViewById(R.id.title);
        descriptionET = findViewById(R.id.description);
        addressET = findViewById(R.id.address);
        salaryET = findViewById(R.id.salary);
    }

    public void add(View view) {

        emailid = emailidET.getText().toString();
        companyname = companynameET.getText().toString();
        title = titleET.getText().toString();
        description = descriptionET.getText().toString();
        address = addressET.getText().toString();
        salary = salaryET.getText().toString();
        //validation start

        if (emailid.equalsIgnoreCase("")) {
            emailidET.setError("Please enter email");
            emailidET.requestFocus();
            return;
        }
        if (companyname.equalsIgnoreCase("")) {
            companynameET.setError("Please enter first name");
            companynameET.requestFocus();
            return;
        }
        if (title.equalsIgnoreCase("")) {
            titleET.setError("Please enter last name");
            titleET.requestFocus();
            return;
        }
        if (description.equalsIgnoreCase("")) {
            descriptionET.setError("Please enter date of birth");
            descriptionET.requestFocus();
            return;
        }
        if (address.equalsIgnoreCase("")) {
            addressET.setError("Please enter password");
            addressET.requestFocus();
            return;
        }
        if (salary.equalsIgnoreCase("")) {
            salaryET.setError("Please enter password");
            salaryET.requestFocus();
            return;
        }

        //validation end

        new PostJob.upl(PostJob.this, emailid,
                companyname, title, description,address,salary).execute();
    }

    public void Back(View view) {
        Intent intent=new Intent(PostJob.this,profilefind.class);
        startActivity(intent);
    }


    private class upl extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressBar;
        private String emailid;
        private String companyname;
        private String title;
        private String description;
        private String address;
        private String salary;

        public upl(Activity activity, String emailid,
                   String companyname, String title, String description, String address,String salary){
            progressBar = new ProgressDialog(activity);
            this.emailid = emailid;
            this.companyname = companyname;
            this.title = title;
            this.description = description;
            this.address = address;
            this.salary = salary;
        }

        protected void onPreExecute(){
            progressBar.setMessage("Loading...");
            progressBar.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            URL url = null;
            BufferedReader reader = null;
            StringBuilder stringBuilder = new StringBuilder();

            try {
                url = new URL("http://"+ Constant.WEB_SERVICE_HOST +":"+Constant.WEB_SERVICE_PORT+"/Web_Application/webresources/mobile/post1&"+emailid+"&"+companyname+"&"+title+"&"+description+"&"+address+"&"+salary);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                // uncomment this if you want to write output to this url

                connection.setDoInput(true);
                connection.setInstanceFollowRedirects( false );

                // give it 15 seconds to respond
                connection.setReadTimeout(15*1000);
                connection.connect();
                // read the output from the server
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }

                System.out.println("url: "+stringBuilder.toString());
            }
            catch (Exception e) {
                e.printStackTrace();
                try {
                    throw e;
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            finally {
                if (reader != null) {
                    try{
                        reader.close();
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return stringBuilder.toString();
        }
        @Override

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            System.out.println(result);
            try {
                JSONObject loginResponse = new JSONObject(result);
                if(loginResponse.length()!=0 &&
                        loginResponse.get("status").toString().equalsIgnoreCase("OK") ) {


                    Intent intent = new Intent(PostJob.this, ModifyProfileFinder.class);
                    startActivity(intent);
                    progressBar.dismiss();
                }
                else{
                    Toast toast = Toast.makeText(getApplicationContext(),"Something went wrong, please try again.",Toast.LENGTH_LONG);

                    progressBar.dismiss();
                    toast.show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}