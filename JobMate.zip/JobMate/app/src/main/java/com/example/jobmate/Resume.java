package com.example.jobmate;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Resume extends AppCompatActivity {
    private static final String TAG = "Resume";
    private TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private Button button;
    private Button button1;
    EditText emailET, fnameET, lnameET, experienceET, companyET, cityET,educationET;
    String email, fname, lname, experience, company,city,education;
    Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resume);

        emailET = findViewById(R.id.emailid);
        fnameET = findViewById(R.id.fname);
        lnameET = findViewById(R.id.lname);
        experienceET = findViewById(R.id.experience);
        companyET = findViewById(R.id.company);
        cityET = findViewById(R.id.city);
        educationET = findViewById(R.id.education);

    }

    public void upload(View view) {

        email = emailET.getText().toString();
        fname = fnameET.getText().toString();
        lname = lnameET.getText().toString();
        experience = experienceET.getText().toString();
        company = companyET.getText().toString();
        city = cityET.getText().toString();
        education = educationET.getText().toString();
        //validation start

        if (email.equalsIgnoreCase("")) {
            emailET.setError("Please enter email");
            emailET.requestFocus();
            return;
        }
        if (fname.equalsIgnoreCase("")) {
            fnameET.setError("Please enter first name");
            fnameET.requestFocus();
            return;
        }
        if (lname.equalsIgnoreCase("")) {
            lnameET.setError("Please enter last name");
            lnameET.requestFocus();
            return;
        }
        if (experience.equalsIgnoreCase("")) {
            experienceET.setError("Please enter date of birth");
            experienceET.requestFocus();
            return;
        }
        if (company.equalsIgnoreCase("")) {
            companyET.setError("Please enter password");
            companyET.requestFocus();
            return;
        }
        if (city.equalsIgnoreCase("")) {
            cityET.setError("Please enter password");
            cityET.requestFocus();
            return;
        }
        if (education.equalsIgnoreCase("")) {
            educationET.setError("Please enter password");
            educationET.requestFocus();
            return;
        }

        //validation end

        new Resume.upl(Resume.this, email,
                fname, lname, experience,company,city,education).execute();
    }

    public void Back(View view) {
        Intent intent=new Intent(Resume.this,profilefind.class);
        startActivity(intent);
    }


    private class upl extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressBar;
        private String email;
        private String fname;
        private String lname;
        private String experience;
        private String company;
        private String city;
        private String education;

        public upl(Activity activity, String email,
                        String fname, String lname, String experience, String company,String city,String education){
            progressBar = new ProgressDialog(activity);
            this.email = email;
            this.fname = fname;
            this.lname = lname;
            this.experience = experience;
            this.company = company;
            this.city = city;
            this.education= education;
        }

        protected void onPreExecute(){
            progressBar.setMessage("Loading...");
            progressBar.show();
        }

        @Override
        protected String doInBackground(Void... voids) {
            URL url = null;
            BufferedReader reader = null;
            StringBuilder stringBuilder = new StringBuilder();

            try {
                url = new URL("http://"+ Constant.WEB_SERVICE_HOST +":"+Constant.WEB_SERVICE_PORT+"/Web_Application/webresources/mobile/resume&"+email+"&"+fname+"&"+lname+"&"+experience+"&"+company+"&"+city+"&"+education);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                // uncomment this if you want to write output to this url

                connection.setDoInput(true);
                connection.setInstanceFollowRedirects( false );

                // give it 15 seconds to respond
                connection.setReadTimeout(15*1000);
                connection.connect();
                // read the output from the server
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }

                System.out.println("url: "+stringBuilder.toString());
            }
            catch (Exception e) {
                e.printStackTrace();
                try {
                    throw e;
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            finally {
                if (reader != null) {
                    try{
                        reader.close();
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            return stringBuilder.toString();
        }
        @Override

        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            System.out.println(result);
            try {
                JSONObject loginResponse = new JSONObject(result);
                if(loginResponse.length()!=0 &&
                        loginResponse.get("status").toString().equalsIgnoreCase("OK") ) {


                    Intent intent = new Intent(Resume.this, ModifyProfileFinder.class);
                    startActivity(intent);
                    progressBar.dismiss();
                }
                else{
                    Toast toast = Toast.makeText(getApplicationContext(),"Something went wrong, please try again.",Toast.LENGTH_LONG);

                    progressBar.dismiss();
                    toast.show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}