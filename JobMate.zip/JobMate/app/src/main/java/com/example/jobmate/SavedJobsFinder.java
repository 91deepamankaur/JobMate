package com.example.jobmate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SavedJobsFinder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
